# Add project specific ProGuard/R8 rules here.
# Release minification is currently disabled (isMinifyEnabled = false).
